import flet as ft

file_ctrls = {}

def get_package(pkgid):
  packages = {
    '1': {
         'name': 'launch-attemp1',
         'scenarios': [
           {'scenario': 'launch1',
             'files': [
               {'name':'ephem1.oem',
                'id': 1,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Baseline',
                'grade':'Scheduling',
               },
               {'name':'ephem2.oem',
                'id': 2,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Baseline',
                'grade':'Scheduling',
               },
             ]
           },
           {'scenario': 'launch2',
             'files': [
               {'name':'ephem5.oem',
                'id': 3,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Non-Baseline',
                'grade':'Scheduling',
               },
               {'name':'ephem6.oem',
                'id': 4,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Non-Baseline',
                'grade':'Scheduling',
               },
             ]
           },
         ]
       },
    '2': {
         'name': 'init-acq-attemp2',
         'scenarios': [
           {'scenario': 'init-acq1',
             'files': [
               {'name':'ephem1.oem',
                'id': 5,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Baseline',
                'grade':'Scheduling',
               },
               {'name':'ephem2.oem',
                'id': 6,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Baseline',
                'grade':'Scheduling',
               },
             ]
           },
           {'scenario': 'init-acq2',
             'files': [
               {'name':'ephem5.oem',
                'id': 7,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Non-Baseline',
                'grade':'Scheduling',
               },
               {'name':'ephem6.oem',
                'id': 8,
                'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
                'status':'Propose Non-Baseline',
                'grade':'Scheduling',
               },
             ]
           },
         ]
       },
  }
  return packages[pkgid] 

def build_detail_view(path, pkgid, page):

  def load_file_details(e):
    ctrl = e.control
    id = file_ctrls[ctrl]
    #print("id: %s" % str(id))
    page.go("/file/%s" % str(id))

  def on_status_tap(e):

    def cancel_dlg(e):
      dlg_modal.open = False
      page.update()

    def ok_dlg(e):
      status_cell.content.value = status_dd.value
      dlg_modal.open = False
      page.update()

    status_cell = e.control
    status_dd = ft.Dropdown(options=[ft.dropdown.Option("Propose Baseline"),ft.dropdown.Option("Propose Non-Baseline")], value=status_cell.content.value)
    dlg_modal = ft.AlertDialog(
      modal=True,
      title=ft.Text("Status"),
      content=status_dd,
      actions=[
        ft.TextButton("OK", on_click=ok_dlg),
        ft.TextButton("Cancel", on_click=cancel_dlg),
      ],
      actions_alignment=ft.MainAxisAlignment.END,
      )
    page.dialog = dlg_modal
    dlg_modal.open = True
    page.update()

  def on_grade_tap(e):

    def cancel_dlg(e):
      dlg_modal.open = False
      page.update()

    def ok_dlg(e):
      grade_cell.content.value = grade_dd.value
      dlg_modal.open = False
      page.update()

    grade_cell = e.control
    grade_dd = ft.Dropdown(options=[ft.dropdown.Option("Predict"),ft.dropdown.Option("Scheduling")], value=grade_cell.content.value)
    dlg_modal = ft.AlertDialog(
      modal=True,
      title=ft.Text("Grade"),
      content=grade_dd,
      actions=[
        ft.TextButton("OK", on_click=ok_dlg),
        ft.TextButton("Cancel", on_click=cancel_dlg),
      ],
      actions_alignment=ft.MainAxisAlignment.END,
      )
    page.dialog = dlg_modal
    dlg_modal.open = True
    page.update()

  def on_timestamp_tap(e):

    def cancel_dlg(e):
      dlg_modal.open = False
      page.update()

    def ok_dlg(e):
      ts_cell.content.value = ts_tf.value
      dlg_modal.open = False
      page.update()

    ts_cell = e.control
    ts_tf = ft.TextField(value=ts_cell.content.value)
    dlg_modal = ft.AlertDialog(
      modal=True,
      title=ft.Text("Date Time"),
      content=ts_tf,
      actions=[
        ft.TextButton("OK", on_click=ok_dlg),
        ft.TextButton("Cancel", on_click=cancel_dlg),
      ],
      actions_alignment=ft.MainAxisAlignment.END,
      )
    page.dialog = dlg_modal
    dlg_modal.open = True
    page.update()

  def on_scename_tap(e):
    def cancel_dlg(e):
      dlg_modal.open = False
      page.update()

    def ok_dlg(e):
      ts_cell.content.value = ts_tf.value
      dlg_modal.open = False
      page.update()

    ts_cell = e.control
    ts_tf = ft.TextField(value=ts_cell.content.value)
    dlg_modal = ft.AlertDialog(
      modal=True,
      title=ft.Text("Scenario Name"),
      content=ts_tf,
      actions=[
        ft.TextButton("OK", on_click=ok_dlg),
        ft.TextButton("Cancel", on_click=cancel_dlg),
      ],
      actions_alignment=ft.MainAxisAlignment.END,
      )
    page.dialog = dlg_modal
    dlg_modal.open = True
    page.update()

  def on_scena_select(e):
    global sel_scename
    if e.data == 'true':
      idx = 0
      for row in scena_tbl.rows:
        if row == e.control:
          row.selected = True
        else:       
          row.selected = False
        idx += 1    
      selected_scename = e.control.cells[0].content.value
      # now populate the files for this scenario
      file_tbl.rows.clear()
      pkg = get_package(pkgid)
      scenarios = pkg['scenarios']
      for scenario in scenarios:
        scename = scenario['scenario']
        if scename == selected_scename:
          files = scenario['files']
          for file in files:
            id = file['id']
            fname = file['name']
            start = file['app_start']
            end = file['app_end']
            status = file['status']
            grade = file['grade']
            cells = []
            cells.append(ft.DataCell(ft.Text(str(id))))
            cells.append(ft.DataCell(ft.Text(fname)))
            cells.append(ft.DataCell(ft.Text(start), show_edit_icon=True, on_tap=on_timestamp_tap))
            cells.append(ft.DataCell(ft.Text(end), show_edit_icon=True, on_tap=on_timestamp_tap))
            cells.append(ft.DataCell(ft.Text(status), show_edit_icon=True, on_tap=on_status_tap))
            cells.append(ft.DataCell(ft.Text(grade), show_edit_icon=True, on_tap=on_grade_tap))
            fctrl = ft.ElevatedButton("...", on_click=load_file_details)
            file_ctrls[fctrl] = id
            cells.append(ft.DataCell(fctrl))
            tabrow = ft.DataRow(cells=cells)
            file_tbl.rows.append(tabrow)
    else:           
      for row in scena_tbl.rows:
        if row == e.control:
          row.selected = False
      selected_scename = None
      file_tbl.rows.clear()
    page.update()

  # setup controls
  scena_columns = [
    ft.DataColumn(ft.Text("Scenario Name")),
    ft.DataColumn(ft.Text("Release To SPS")),
  ]
  columns=[
                ft.DataColumn(ft.Text("ID")),
                ft.DataColumn(ft.Text("File Name")),
                ft.DataColumn(ft.Text("Applicable Start")),
                ft.DataColumn(ft.Text("Applicable End")),
                ft.DataColumn(ft.Text("Status")),
                ft.DataColumn(ft.Text("Grade")),
                ft.DataColumn(ft.Text("Details")),
           ]
  controls = []
  pkg = get_package(pkgid)
  pkgname = pkg['name']
  titlename = '"%s" package' % pkgname
  controls.append(ft.AppBar(title=ft.Text(titlename), bgcolor=ft.colors.SURFACE_VARIANT))
  scena_tbl = ft.DataTable(show_checkbox_column=True,columns=scena_columns)
  controls.append(scena_tbl)
  scenarios = pkg['scenarios']
  is_first = True
  for scenario in scenarios:
    scename = scenario['scenario']
    scena_cells = []
    scena_cells.append(ft.DataCell(ft.Text(scename), show_edit_icon=True, on_tap=on_scename_tap))
    scectrl = ft.ElevatedButton("->")
    scena_cells.append(ft.DataCell(scectrl))
    scena_tbl.rows.append(ft.DataRow(cells=scena_cells, on_select_changed=on_scena_select))
    if is_first:
      is_first = False
      scena_tbl.rows[-1].selected = True
      rows = []
      files = scenario['files']
      for file in files:
        id = file['id']
        fname = file['name']
        start = file['app_start']
        end = file['app_end']
        status = file['status']
        grade = file['grade']
        cells = []
        cells.append(ft.DataCell(ft.Text(str(id))))
        cells.append(ft.DataCell(ft.Text(fname)))
        cells.append(ft.DataCell(ft.Text(start), show_edit_icon=True, on_tap=on_timestamp_tap))
        cells.append(ft.DataCell(ft.Text(end), show_edit_icon=True, on_tap=on_timestamp_tap))
        cells.append(ft.DataCell(ft.Text(status), show_edit_icon=True, on_tap=on_status_tap))
        cells.append(ft.DataCell(ft.Text(grade), show_edit_icon=True, on_tap=on_grade_tap))
        fctrl = ft.ElevatedButton("...", on_click=load_file_details)
        file_ctrls[fctrl] = id
        cells.append(ft.DataCell(fctrl))
        tabrow = ft.DataRow(cells=cells)
        rows.append(tabrow)
      file_tbl = ft.DataTable(columns=columns, rows=rows)
      controls.append(file_tbl)
  #controls.append(ft.ElevatedButton("Go Home", on_click=lambda _: page.go("/")))
  view = ft.View(path,
      controls,
      scroll = ft.ScrollMode.ALWAYS
    )
  return view
