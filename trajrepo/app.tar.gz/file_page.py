import flet as ft
import traceback

def get_file(fid):
  files = {
    '1' : {'name':'ephem1.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Baseline',
     'grade':'Scheduling',
     'specifics': {
       'launch_start' : '2023-09-06T00:00:00',
       'launch_end' : '2023-10-06T00:00:00',
       'launch_times' : [
         '2023-09-06T00:00:00',
         '2023-09-06T01:00:00',
         '2023-09-06T02:00:00',
         '2023-09-06T08:00:00',
         '2023-09-06T11:00:00',
         '2023-10-06T00:00:00',
       ]
     }
    },
    '2' : {'name':'ephem2.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Baseline',
     'grade':'Scheduling',
     'specifics': {
       'launch_start' : '2023-09-06T00:00:00',
       'launch_end' : '2023-10-06T00:00:00',
       'launch_times' : [
         '2023-09-06T00:00:00',
         '2023-09-06T01:00:00',
         '2023-09-06T02:00:00',
         '2023-09-06T08:00:00',
         '2023-09-06T11:00:00',
         '2023-10-06T00:00:00',
       ]
     }
    },
    '3' : {'name':'ephem5.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Non-Baseline',
     'grade':'Scheduling',
     'specifics': {
       'launch_start' : '2023-09-06T00:00:00',
       'launch_end' : '2023-10-06T00:00:00',
       'launch_times' : [
         '2023-09-06T00:00:00',
         '2023-09-06T01:00:00',
         '2023-09-06T02:00:00',
         '2023-09-06T08:00:00',
         '2023-09-06T11:00:00',
         '2023-10-06T00:00:00',
       ]
     }
    },
    '4' : {'name':'ephem6.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Non-Baseline',
     'grade':'Scheduling',
     'specifics': {
       'launch_start' : '2023-09-06T00:00:00',
       'launch_end' : '2023-10-06T00:00:00',
       'launch_times' : [
         '2023-09-06T00:00:00',
         '2023-09-06T01:00:00',
         '2023-09-06T02:00:00',
         '2023-09-06T08:00:00',
         '2023-09-06T11:00:00',
         '2023-10-06T00:00:00',
       ]
     }
    }, 
    '5' : {'name':'ephem1.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Baseline',
     'grade':'Scheduling',
     'specifics': {
       'sigma':'9',
     }
    },
    '6' : {'name':'ephem2.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Baseline',
     'grade':'Scheduling',
     'specifics': {
       'sigma':'9',
     }
    },
    '7' : {'name':'ephem5.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Non-Baseline',
     'grade':'Scheduling',
     'specifics': {
       'sigma':'10',
     }
    },
    '8' : {'name':'ephem6.oem',
     'app_start':'2023-09-06T00:00:00','app_end':'2023-10-06T00:00:00',
     'status':'Propose Non-Baseline',
     'grade':'Scheduling',
     'specifics': {
       'sigma':'10',
      }
    },
  }
  return files[fid]

def build_file_view(path, fid, page):
  file = get_file(fid)
  controls = []
  fname = file['name']
  controls.append(ft.AppBar(title=ft.Text(fname), bgcolor=ft.colors.SURFACE_VARIANT))
  row = ft.Row([ft.TextField(label='Applicable Start Time', value=file['app_start']),ft.TextField(label='Applicable End Time', value=file['app_end'])])
  controls.append(row)
  status = ft.Dropdown(label='Status', options=[ft.dropdown.Option("Propose Baseline"),ft.dropdown.Option("Propose Non-Baseline")], value=file['status'])
  grade = ft.Dropdown(label='Grade', options=[ft.dropdown.Option("Predict"),ft.dropdown.Option("Scheduling")], value=file['grade'])
  row = ft.Row([status,grade])
  controls.append(row)
  try:
    specifics = file['specifics']
    try:
      controls.append(ft.Row([ft.TextField(label='Sigma', value=specifics['sigma'])]))
    except:
      pass
    try:
      row = ft.Row([ft.TextField(label="Launch Window's Start Time", value=specifics['launch_start']),ft.TextField(label="Launch Window's End Time", value=specifics['launch_end'])])
      controls.append(row)
    except:
      pass
    try:
      ltimes = specifics['launch_times']
      label = ft.Text("Launch Time")
      lv = ft.ListView(auto_scroll=True)
      for lt in ltimes:
        lv.controls.append(ft.Text(lt))
      ctrcol = ft.Column(controls=[ft.OutlinedButton("+"), ft.OutlinedButton("-")])
      ltrow = ft.Row([label,ctrcol,lv], vertical_alignment=ft.CrossAxisAlignment.START)
      controls.append(ltrow)
    except:
      #traceback.print_exc()
      pass
  except:
    pass
  controls.append(ft.ElevatedButton("Save"))
  view = ft.View(path, controls, scroll = ft.ScrollMode.ALWAYS)
  return view
