flet publish trajrepo_app.py --base-url trajrepo
