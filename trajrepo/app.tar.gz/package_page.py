import flet as ft

sc_opts = []
sc_dd = None
pkg_tbl = None
selected_pkgid = -1

def get_sc_info():
  return ['ACE','CAS','JNO']

def get_packages(sc):
  return [
    {'ID':1, 'Name': 'launch-attemp1', 'submitted': '2023-09-01T00:00:00'},
    {'ID':2, 'Name': 'init-acq-attemp2', 'submitted': '2023-09-16T00:00:00'},
  ]

def build_package_view(path, page):

  def build_sc_opts():
    scnames = get_sc_info();
    for sc in scnames:
      sc_opts.append(ft.dropdown.Option(sc))
    global sc_dd
    sc_dd = ft.Dropdown(label="Mission", options=sc_opts, width=150, text_size=12, dense=True, content_padding=4, on_change=load_packages)
    return sc_dd

  def build_package_table():
    global pkg_tbl
    pkg_tbl = ft.DataTable(
      show_checkbox_column=True,
      columns=[
        ft.DataColumn(ft.Text("Package ID")),
        ft.DataColumn(ft.Text("Package Name")),
        ft.DataColumn(ft.Text("Submitted Time")),
      ]
    )
    return pkg_tbl

  def load_packages(event):
    sc = sc_dd.value
    pkg_tbl.rows.clear()
    pkgs = get_packages(sc)
    idx = 0
    for pkg in pkgs:
      dr = ft.DataRow(
            cells = [
              ft.DataCell(ft.Text(str(pkg['ID']))),
              ft.DataCell(ft.Text(pkg['Name'])),
              ft.DataCell(ft.Text(pkg['submitted'])),
            ],
            on_select_changed=on_select
          ) 
      pkg_tbl.rows.append(dr)
      idx += 1
    page.update()

  def on_select(e):
    global selected_pkgid
    if e.data == 'true':
      idx = 0
      for row in pkg_tbl.rows:
        if row == e.control:
          row.selected = True
        else:
          row.selected = False
        idx += 1
      selected_pkgid = e.control.cells[0].content.value
    else:
      for row in pkg_tbl.rows:
        if row == e.control:
          row.selected = False
      selected_pkgid = -1
    page.update()

  def on_view_details(e):
    if selected_pkgid != -1:
      page.go("/details/%s" % str(selected_pkgid))

  del_bt = ft.ElevatedButton("Delete")
  details_bt = ft.ElevatedButton("View Details", on_click=on_view_details)

  view = ft.View(
                path,
                [
                    ft.AppBar(title=ft.Text("Upload Packages"), bgcolor=ft.colors.SURFACE_VARIANT),
                    build_sc_opts(),
                    build_package_table(),
                    ft.Row(controls=[details_bt, del_bt]),
                ],
                scroll = ft.ScrollMode.ALWAYS
            )
  return view
