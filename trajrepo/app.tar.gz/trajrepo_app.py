import flet as ft
from package_page import build_package_view
from detail_page import build_detail_view
from file_page import build_file_view

is_setup = False

def main(page: ft.Page):
    page.title = "Trajectory Repo"

    def route_change(route):
        global is_setup
        if not is_setup:
          page.views.clear()
          page.views.append(build_package_view("/", page))
          is_setup = True
        if page.route == "/":
          while len(page.views) > 1:
            page.views.pop()
        troute = ft.TemplateRoute(page.route)
        if troute.match("/details/:pkgid"):
            if len(page.views) == 1:
              page.views.append(build_detail_view(page.route, troute.pkgid, page))
        elif troute.match("/file/:fid"):
            page.views.append(build_file_view(page.route, troute.fid, page))
        page.update()

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)


#ft.app(target=main, view=ft.AppView.WEB_BROWSER)
ft.app(target=main)
